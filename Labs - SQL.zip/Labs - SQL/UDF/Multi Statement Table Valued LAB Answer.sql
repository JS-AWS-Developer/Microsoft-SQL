--Write a Multi-statement Table-Value function which will accept a data 
--range for DOB and return first name,last name and address of employyes with 
--DOB in between that date range. But if no employye has  DOB in the 
--in the given date range, then a dummy row is returned where the Address field 
--is filled with "No matching employees found in the specified date range," 

CREATE function dbo.EmployeeBasedOnDOB(@from as datetime, @to as datetime) 
        returns @EmployeeReturn table 
			(EmployeeID varchar(100))
as
begin

	if exists(select top 1 *
			from HumanResources.Employee 
			where HumanResources.Employee.BirthDate between @from and @to)

		insert into @EmployeeReturn
		select employeeid 
			from HumanResources.Employee 
			where HumanResources.Employee.BirthDate between @from and @to
	else
		insert into @EmployeeReturn
		select 'No matching employees found in the specified date range'

	return

end




--write a select statement to get employees with DOB between 1/1/1974 & 1/1/2000 
SELECT * FROM dbo.EmployeeBasedOnDOB('1/1/1974' , '1/1/2000')


--write a select statement to get employees with DOB between 1/1/1998 & 1/1/2000
SELECT * FROM dbo.EmployeeBasedOnDOB('1/1/1998' , '1/1/2000')