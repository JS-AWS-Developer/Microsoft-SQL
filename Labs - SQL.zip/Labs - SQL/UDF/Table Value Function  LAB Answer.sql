--Write a function takes produtid as input paramenter and returns the columns ProductID, 
-- and the aggregate of year-to-date sales for each product.
IF OBJECT_ID ('dbo.ufn_SalesByProduct', 'IF') IS NOT NULL
    DROP FUNCTION dbo.ufn_SalesByProduct;
GO
CREATE FUNCTION dbo.ufn_SalesByProduct (@productid int)
RETURNS TABLE
AS
RETURN 
(
    SELECT P.ProductID,SUM(SD.LineTotal) AS 'YTD_Total'
    FROM Production.Product AS P 
      INNER JOIN Sales.SalesOrderDetail AS SD ON SD.ProductID = P.ProductID
      INNER JOIN Sales.SalesOrderHeader AS SH ON SH.SalesOrderID = SD.SalesOrderID
    WHERE P.ProductID = @productid
    GROUP BY P.ProductID
);
GO


--Write a select statemnt to get aggregate of year-to-date sales as YTD Total for for product = 980
select * from dbo.ufn_SalesByProduct(980)


--write a select statement to join product table and  dbo.ufn_SalesByStore function in the database
--use CROSS APPLY 
SELECT P.ProductID, P.Name, FN.YTD_TOTAL
    FROM Production.Product AS P 
CROSS APPLY  dbo.ufn_SalesByProduct(P.ProductID) AS FN
ORDER BY P.ProductID