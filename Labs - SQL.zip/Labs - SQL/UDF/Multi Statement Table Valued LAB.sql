--Write a Multi-statement Table-Value function which will accept a data 
--range for DOB and return first name,last name and address of employyes with 
--DOB in between that date range. But if no employye has  DOB in the 
--in the given date range, then a dummy row is returned where the Address field 
--is filled with "No matching employees found in the specified date range," 


--write a select statement to get employees with DOB between 1/1/1974 & 1/1/2000 


--write a select statement to get employees with DOB between 1/1/1998 & 1/1/2000
