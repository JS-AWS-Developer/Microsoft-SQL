--Write a function which takes ProductID as input parameter and returns the aggregated quantity 
--of the products in inventory as the single return value.



--Write a function which takes ProductID and location as input parameters and returns the 
--aggregated quantity of the products in inventory as the single return value.



-- Using the function dbo.ufnGetInventoryStockByProduct, get the average number of procuct stored for
-- product id 1



-- Using the function dbo.ufnGetInventoryStockByProductAndLocation, get the average number of procuct 
--stored for product id 5 and location id 50



-- write a select statement using above created functions to show quantity total bases on product



-- write a select statement using above created functions to show quantity total bases on product & location



--Now, combine above written SQL statements in to a single statement. 
-- write a select statement using above created functions to show quantity total bases on product
