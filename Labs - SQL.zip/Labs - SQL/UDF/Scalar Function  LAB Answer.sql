--Write a function which takes ProductID as input parameter and returns the aggregated quantity 
--of the products in inventory as the single return value.
IF OBJECT_ID ('dbo.ufnGetInventoryStockByProduct', 'FN') IS NOT NULL
    DROP FUNCTION ufnGetInventoryStock;
GO
CREATE FUNCTION dbo.ufnGetInventoryStockByProduct(@ProductID int)
RETURNS int 
AS 
-- Returns the stock level for the product.
BEGIN
    DECLARE @ret int;
    
    SELECT @ret = SUM(p.Quantity) 
    FROM Production.ProductInventory p 
    WHERE p.ProductID = @ProductID 

     IF (@ret IS NULL) 
        SET @ret = 0;
        
    RETURN @ret;
END;
GO



--Write a function which takes ProductID and location as input parameters and returns the 
--aggregated quantity of the products in inventory as the single return value.
IF OBJECT_ID ('dbo.ufnGetInventoryStockByProductAndLocation', 'FN') IS NOT NULL
    DROP FUNCTION ufnGetInventoryStock;
GO
CREATE FUNCTION dbo.ufnGetInventoryStockByProductAndLocation(@ProductID int,@LocationID as int)
RETURNS int 
AS 
-- Returns the stock level for the product.
BEGIN
    DECLARE @ret int;
    
    SELECT @ret = SUM(p.Quantity) 
    FROM Production.ProductInventory p 
    WHERE p.ProductID = @ProductID 
        AND p.LocationID = @LocationID;
        
     IF (@ret IS NULL) 
        SET @ret = 0;
        
    RETURN @ret;
END;
GO


-- Using the function dbo.ufnGetInventoryStockByProduct, get the average number of procuct stored for
-- product id 1
select dbo.ufnGetInventoryStockByProduct(1)


-- Using the function dbo.ufnGetInventoryStockByProductAndLocation, get the average number of procuct 
--stored for product id 5 and location id 50
select dbo.ufnGetInventoryStockByProductAndLocation(1,50)


-- write a select statement using above created functions to show quantity total bases on product
select *,
	dbo.ufnGetInventoryStockByProduct(ProductID)
from Production.ProductInventory 


-- write a select statement using above created functions to show quantity total bases on product & location
select *,
	dbo.ufnGetInventoryStockByProductAndLocation(ProductID,LocationID)
from Production.ProductInventory 


--Now, combine above written SQL statements in to a single statement. 
-- write a select statement using above created functions to show quantity total bases on product
select *,
	dbo.ufnGetInventoryStockByProduct(ProductID), 
	dbo.ufnGetInventoryStockByProductAndLocation(ProductID,LocationID)
from Production.ProductInventory 


