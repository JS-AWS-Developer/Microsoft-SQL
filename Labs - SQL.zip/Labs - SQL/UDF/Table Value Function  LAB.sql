--Write a function takes produtid as input paramenter and returns the columns ProductID, 
-- and the aggregate of year-to-date sales for each product.



--Write a select statemnt to get aggregate of year-to-date sales as YTD Total for for product = 980
--using above created function


--write a select statement to join Production.Product table and  above created function 
--using CROSS APPLY 
