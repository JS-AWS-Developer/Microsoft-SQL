-- show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name,
--counrty region code for all sales persons. Hint: use tables Sales.SalesPerson & Sales.SalesTerritory
select SalesPersonID,sp.SalesQuota,sp.Bonus,sp.CommissionPct,sp.SalesYTD,sp.SalesLastYear,st.Name,st.CountryRegionCode
from Sales.SalesPerson  sp
inner join Sales.SalesTerritory st on sp.TerritoryID = st.TerritoryID

--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons with no sales generated last year. Hint: use tables Sales.SalesPerson 
--& Sales.SalesTerritory
select SalesPersonID,sp.SalesQuota,sp.Bonus,sp.CommissionPct,sp.SalesYTD,sp.SalesLastYear,st.Name,st.CountryRegionCode
from Sales.SalesPerson  sp
inner join Sales.SalesTerritory st on sp.TerritoryID = st.TerritoryID
where sp.SalesLastYear = 0 

--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons working in nort america. Hint: use tables Sales.SalesPerson & 
--Sales.SalesTerritory
select SalesPersonID,sp.SalesQuota,sp.Bonus,sp.CommissionPct,sp.SalesYTD,sp.SalesLastYear,
		st.Name,st.CountryRegionCode
from Sales.SalesPerson  sp
inner join Sales.SalesTerritory st on sp.TerritoryID = st.TerritoryID
where st.[Group] = 'North America' 


--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons with sales quota more than 250000. Hint: use tables Sales.SalesPerson 
--& Sales.SalesTerritory
select SalesPersonID,sp.SalesQuota,sp.Bonus,sp.CommissionPct,sp.SalesYTD,sp.SalesLastYear,st.Name,st.CountryRegionCode
from Sales.SalesPerson  sp
inner join Sales.SalesTerritory st on sp.TerritoryID = st.TerritoryID
where sp.SalesQuota > 250000


--show sales person ID,first name,last name,email,phone number, sales quota,bonus,commission, saled this year,
--last year name, territory name,counrty region code for all sales persons. Hint: use tables 
--Sales.SalesPerson,Person.Contact & Sales.SalesTerritory
select sp.SalesPersonID,sp.SalesQuota,sp.Bonus,sp.CommissionPct,sp.SalesYTD,sp.SalesLastYear,st.Name,st.CountryRegionCode,
	c.FirstName,c.LastName,c.EmailAddress
from Sales.SalesPerson  sp
inner join Sales.SalesTerritory st on sp.TerritoryID = st.TerritoryID
inner join HumanResources.Employee e on sp.SalesPersonID = e.EmployeeID
inner join Person.Contact c on c.ContactID = e.ContactID










