--Show all customers who has not placed an order yet. 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables
SELECT *
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID
WHERE s.SalesOrderID IS NULL 
ORDER BY c.CustomerID


--Can you impliment above logic using a RIGHT OUTER JOIN? 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables
SELECT *
FROM Sales.SalesOrderHeader s 
RIGHT OUTER JOIN Sales.Customer c ON c.CustomerID = s.CustomerID
WHERE s.SalesOrderID IS NULL 
ORDER BY c.CustomerID


--Show all customers who has not placed an online order yet. 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables
SELECT c.CustomerID,s.SalesOrderID,s.OnlineOrderFlag
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID
	and s.OnlineOrderFlag = 1
WHERE s.SalesOrderID IS NULL 
ORDER BY S.CustomerID


--Show all customers who has not placed an order in year 2004 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables
SELECT *
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID
	and year(s.OrderDate) = 2004
--WHERE s.SalesOrderID IS NULL 
ORDER BY c.CustomerID


--Show all customers who has not placed an order yet with their address information . 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables
SELECT a.*
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID
inner join Sales.CustomerAddress ca on c.CustomerID = ca.CustomerID
inner join Person.Address a on a.AddressID = ca.AddressID
WHERE s.SalesOrderID IS NULL 


--Show all the territories with out any customer yet(if any) 
--Hint: Use Sales.Customer & Sales.SalesTerritory tables
SELECT t.Name, CustomerID
FROM Sales.SalesTerritory t 
LEFT OUTER JOIN Sales.Customer c ON t.TerritoryID = c.TerritoryID
WHERE c.CustomerID IS NULL 



--Show me all us customers who has not placed an order yet in USA.  
--Hint: Use Sales.Customer,Sales.SalesOrderHeader & Sales.SalesTerritory tables
SELECT C.*
FROM Sales.Customer c 
INNER JOIN Sales.SalesTerritory t ON c.TerritoryID = t.TerritoryID 
	AND T.CountryRegionCode = 'US'
LEFT OUTER JOIN Sales.SalesOrderHeader h ON h.CustomerID = c.CustomerID 
WHERE h.CustomerID IS NULL
ORDER BY c.CustomerID


--Show all the possible combination of SalesPersonID and TerritoryID.Use cross join 
--Hint: Use Sales.SalesPerson & Sales.SalesTerritory tables
SELECT SP.SalesPersonID,T.TerritoryID 
FROM Sales.SalesPerson SP 
CROSS JOIN Sales.SalesTerritory T


--Show manager and their employee information 
--Hint: Use self join of HumanResources.Employee table
SELECT  M.ManagerID AS 'ManagerID',
	 M1.ContactID AS 'ManagerContactID',
	 M1.FirstName AS 'ManagerFirstName',
	 M1.LastName AS 'ManagerLastName',
	 M.Title AS 'ManagerTitle',
	 E.EmployeeID AS 'EmployeeID',
	 E1.ContactID AS 'EmployeeContactID',
	 E1.FirstName AS 'EmployeeFirstName',
	 E1.LastName AS 'EmployeeLastName',
	 E.Title AS 'EmployeeTitle'
FROM HumanResources.Employee E 
INNER JOIN HumanResources.Employee M ON E.ManagerID = M.EmployeeID 
INNER JOIN Person.Contact E1 ON E1.ContactID = E.ContactID 
INNER JOIN Person.Contact M1 ON M1.ContactID = M.ContactID
ORDER BY M1.LastName







