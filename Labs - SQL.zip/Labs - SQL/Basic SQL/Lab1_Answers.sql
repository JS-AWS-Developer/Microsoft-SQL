------------------------------------------------------
--use Sales.SalesPerson tabel for following questions. 
------------------------------------------------------

--Show all rows and all columns from Sales.SalesPerson table. 
select * 
from Sales.SalesPerson

--Show all rows and all columns from Sales.SalesPerson table. Order it by sales amount ascending. 
select * 
from Sales.SalesPerson
order by SalesYTD

--Show sales personid, sales quota,commision,sales and last year sales information for from Sales.SalesPerson table. 
--Order it by sales amount decending.
select SalesPersonID,SalesQuota,CommissionPct,SalesYTD,SalesLastYear 
from Sales.SalesPerson
order by SalesYTD desc

--How many sales persons are there in the company  
select COUNT(*) 
from Sales.SalesPerson

--which sales person made highest sales so far in this year? 
select top 1 * 
from Sales.SalesPerson
order by SalesYTD desc 

--which sales person made least sales so far in this year? 
select top 1 * 
from Sales.SalesPerson
order by SalesYTD

--show top 25 percent of sales person based on their previous year sales. 
select top 25 percent *  
from Sales.SalesPerson
order by SalesLastYear desc

--show the earning of each sales person so far in this year (use columns bonus 
--and commission for computation).
select *, Bonus + (SalesYTD * CommissionPct) as 'total earning' 
from Sales.SalesPerson
order by SalesLastYear

--BONUS QUESTION: Order above resultS based on total earning so far. 
select *, Bonus + (SalesYTD * CommissionPct) as 'total_earning' 
from Sales.SalesPerson
order by total_earning desc 

--Show all sales persons does not have a territory. 
select *
from Sales.SalesPerson
where TerritoryID is null 

--Show all sales persons with specific territory. 
select *
from Sales.SalesPerson
where TerritoryID is not null 

-- which are the distinct territory IDs in the table. 
select distinct TerritoryID
from Sales.SalesPerson

-- show all sales persons working on TerritoryID 1. 
select *
from Sales.SalesPerson
where TerritoryID = 1

--BONUS QUESTION:  show the top sales persons working on TerritoryID 1 based on total sales made so far this year. 
select top 1 *
from Sales.SalesPerson
where TerritoryID = 1
order by SalesYTD desc

-- show all sales persons working on TerritoryID 6 with more than $3000000 sales so far this year. . 
select *
from Sales.SalesPerson
where TerritoryID = 6 and SalesYTD >= 3000000


--show sales person with no territory id and sales quota. 
select *
from Sales.SalesPerson
where TerritoryID is null and salesquota is null 

--show sales persons with sales quota less than $280000 or sales greater than $4000000
select *
from Sales.SalesPerson
where salesquota < 280000 or SalesYTD > 4000000




---------------------------------------------------------
--use Sales.SalesTerritory table for following questions. 
---------------------------------------------------------

-- show all the sales territories in USA. 
select * from Sales.SalesTerritory 
WHERE CountryRegionCode = 'US' 


--show sales information of sales person working in USA using corelated sub query. 
--use Sales.SalesTerritory and Sales.SalesPerson tables for this query 
select * 
from Sales.SalesPerson
where exists (select * 
			from Sales.SalesTerritory  
			where Sales.SalesTerritory.TerritoryID = Sales.SalesPerson.TerritoryID
				and CountryRegionCode = 'US'
			) 
			
-- impliement above logic using an IN clause. 
select * 
from Sales.SalesPerson
where Sales.SalesPerson.TerritoryID IN (select Sales.SalesTerritory.TerritoryID
			from Sales.SalesTerritory  
			where CountryRegionCode = 'US'
			) 


---------------------------------------------------------
--use Production.Product table for following questions. 
---------------------------------------------------------
-- select all produts with name starting with "chain" 			
select *
from Production.Product
where Name like 'chain%'


-- select all produts with name ends with "bolt" 			
select *
from Production.Product
where Name like '%bolt'

--show name and color of all the produts. If the color column is null then display color as  "white" 
--use ISNULL function for this
select Name,ISNULL(color,'White')
from Production.Product
