--show products with no production price history . 


--show products with no production price history in year 2002. 


--show products with no production price history in year 2002 with sub catagory name 
--	starts with "Bike". 


--show all the models with no matching products availabele. 


--show all purchase order details records where the product sale is price less than the product 
--	list price(based on the order date). 
