--Show all customers who has not placed an order yet. 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables


--Can you impliment above logic using a RIGHT OUTER JOIN? 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables


--Show all customers who has not placed an online order yet. 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables


--Show all customers who has not placed an order in year 2004 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables


--Show all customers who has not placed an order yet with their contact information . 
--Hint: Use Sales.Customer & Sales.SalesOrderHeader tables


--Show all the territories with out an customer yet(if any) 
--Hint: Use Sales.Customer & Sales.SalesTerritory tables



--Show all customers who has not placed an order yet in US Territory.  
--Hint: Use Sales.Customer,Sales.SalesOrderHeader & Sales.SalesTerritory tables


--Show all the possible combination of SalesPersonID and TerritoryID.Use CROSS JOIN 
--Hint: Use Sales.SalesPerson & Sales.SalesTerritory tables


--Show manager and their employee information 
--Hint: Use self join of HumanResources.Employee table





