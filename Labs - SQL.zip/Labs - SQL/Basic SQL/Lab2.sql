--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name,
--counrty region code for all sales persons. Hint: use tables Sales.SalesPerson & Sales.SalesTerritory


--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons with no sales generated last year. Hint: use tables Sales.SalesPerson 
--& Sales.SalesTerritory


--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons working in nort america. Hint: use tables Sales.SalesPerson & 
--Sales.SalesTerritory


--show sales person ID,sales quota,bonus,commission, saled this year,last year name, territory name, 
--counrty region code for sales persons with sales quota more than 250000. Hint: use tables Sales.SalesPerson 
--& Sales.SalesTerritory


--show sales person ID,first name,last name,email,phone number, sales quota,bonus,commission, saled this year,
--last year name, territory name,counrty region code for all sales persons. Hint: use tables 
--Sales.SalesPerson,Person.Contact & Sales.SalesTerritory

