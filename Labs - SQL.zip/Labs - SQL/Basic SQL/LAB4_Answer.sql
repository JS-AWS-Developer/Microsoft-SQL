-- show products with no production price history . 
select p.*
from Production.Product p 
left outer join Production.ProductListPriceHistory ph on ph.ProductID = p.ProductID
where ph.ProductID is null


-- show products with no production price history in year 2002. 
select p.*
from Production.Product p 
left outer join Production.ProductCostHistory ph on ph.ProductID = p.ProductID
	and ph.StartDate between '1/1/2002' and '12/31/2002'
where ph.ProductID is null


-- show products with no production price history in year 2002 with sub catagory name starts with "Bike". 
select p.* from Production.Product p 
inner join Production.ProductSubcategory sc on p.ProductSubcategoryID=sc.ProductSubcategoryID 
and sc.Name like 'bike%'
left outer join Production.ProductListPriceHistory ph on p.ProductID = ph.ProductID and year (ph.StartDate) = 2002
where ph.ProductID is null


-- show all the models with no matching products availabele. 
select pm.* 
from Production.ProductModel pm 
left outer join Production.Product p  on pm.ProductModelID = p.ProductModelID
where p.ProductID is null 


--show all purchase order details records where the product sale is price less than the product 
--list price(based on the order date). Show products sales only if there is a historical information 
--available. 
select pd.*
from Production.Product p  
inner join Purchasing.PurchaseOrderDetail pd  on pd.ProductID = p.ProductID
inner join Purchasing.PurchaseOrderHeader ph on ph.PurchaseOrderID = pd.PurchaseOrderID
left outer join Production.ProductListPriceHistory lp on lp.ProductID = p.ProductID
	and ph.OrderDate between lp.StartDate and isnull(lp.EndDate,GETDATE())
	and lp.ListPrice > pd.UnitPrice 
where lp.ProductID is not null 


