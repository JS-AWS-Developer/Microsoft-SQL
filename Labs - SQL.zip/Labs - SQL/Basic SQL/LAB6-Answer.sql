SELECT c.FirstName, c.LastName
    ,ROW_NUMBER() OVER (ORDER BY a.PostalCode) AS 'Row Number'
    ,RANK() OVER (ORDER BY a.PostalCode) AS 'Rank'
    ,DENSE_RANK() OVER (ORDER BY a.PostalCode) AS 'Dense Rank'
    ,NTILE(4) OVER (ORDER BY a.PostalCode) AS 'Quartile'
    ,s.SalesYTD, a.PostalCode
FROM Sales.SalesPerson s 
    INNER JOIN Person.Contact c 
        ON s.SalesPersonID = c.ContactID
    INNER JOIN Person.Address a 
        ON a.AddressID = c.ContactID
WHERE TerritoryID IS NOT NULL 
    AND SalesYTD <> 0;



--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.  
--Aales order with same subtotal should get the same rank number. 
select DENSE_RANK() OVER (ORDER BY sh.SubTotal) AS 'rank',
	sh.SalesOrderNumber,sh.SubTotal,sh.CustomerID
from Sales.SalesOrderHeader sh

    
    
    
--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.  
--If there is two sales order with same subtotal, then use customerid to determine the rank.  
select DENSE_RANK() OVER (ORDER BY sh.SubTotal,sh.CustomerID) AS 'rank',
	sh.SalesOrderNumber,sh.SubTotal,sh.CustomerID
from Sales.SalesOrderHeader sh




--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.
--There should be a seperate rank for sales in each Territory
select ROW_NUMBER() OVER (partition by sh.TerritoryID ORDER BY sh.SubTotal) AS 'rank',
	 sh.TerritoryID,sh.SalesOrderNumber,sh.SubTotal
from Sales.SalesOrderHeader sh



--Show me the 8th best sales in each territory 
select TerritoryID,SalesOrderNumber,SubTotal 
from 
	(
	select rank = ROW_NUMBER() OVER (partition by sh.TerritoryID ORDER BY sh.SubTotal desc),
		 sh.TerritoryID,sh.SalesOrderNumber,sh.SubTotal
	from Sales.SalesOrderHeader sh
	) main 
where rank = 8




--Show me the 8th worst sales in each territory 
select TerritoryID,SalesOrderNumber,SubTotal 
from 
	(
	select rank = ROW_NUMBER() OVER (partition by sh.TerritoryID ORDER BY sh.SubTotal asc),
		 sh.TerritoryID,sh.SalesOrderNumber,sh.SubTotal
	from Sales.SalesOrderHeader sh
	) main 
where rank = 8



--Show me the 8th worst sales in each territory  with territory information 
select t.TerritoryID,t.Name,t.CountryRegionCode,main.SalesOrderNumber,main.SubTotal 
from 
	(
	select rank = ROW_NUMBER() OVER (partition by sh.TerritoryID ORDER BY sh.SubTotal asc),
		 sh.TerritoryID,sh.SalesOrderNumber,sh.SubTotal
	from Sales.SalesOrderHeader sh
	) main 
inner join Sales.SalesTerritory t on t.TerritoryID = main.TerritoryID
where rank = 8



--Show me the best 5 sales in each territory with territory information for year 2001
select t.Name,t.CountryRegionCode,rank,main.SalesOrderNumber,main.SubTotal 
from 
	(
	select rank = ROW_NUMBER() OVER (partition by sh.TerritoryID ORDER BY sh.SubTotal desc),
		 sh.TerritoryID,sh.SalesOrderNumber,sh.SubTotal
	from Sales.SalesOrderHeader sh
	where YEAR(sh.OrderDate) = 2001
	) main 
inner join Sales.SalesTerritory t on t.TerritoryID = main.TerritoryID
where rank <= 5
order by t.CountryRegionCode,rank 



--Show me the best 5 sales in each year for each territory with territory information. 
select main.TerritoryID,t.Name,t.CountryRegionCode,main.year,rank,main.SalesOrderNumber,main.SubTotal 
from 
	(
	select rank = ROW_NUMBER() OVER (partition by sh.TerritoryID,year(sh.OrderDate) ORDER BY sh.SubTotal desc),
		 sh.TerritoryID,
		 year = year(sh.OrderDate),
		 sh.SalesOrderNumber,sh.SubTotal
	from Sales.SalesOrderHeader sh
	) main 
inner join Sales.SalesTerritory t on t.TerritoryID = main.TerritoryID
where rank <= 5
order by main.TerritoryID,t.CountryRegionCode,year,rank 



--show avg,min and max values for each product in each territory
select DISTINCT 
	sh.TerritoryID,sd.ProductID,
	max_value = MAX(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID),
	min_value = MIN(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID),
	avg_value = AVG(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID)
from Sales.SalesOrderDetail sd
inner join Sales.SalesOrderHeader sh on sh.SalesOrderID = sd.SalesOrderID
ORDER BY sh.TerritoryID,sd.ProductID


--show avg,min and max values for each product for entire territory
select DISTINCT 
	sh.TerritoryID,sd.ProductID,
	max_value = MAX(sd.UnitPrice) OVER (partition by sd.ProductID),
	min_value = MIN(sd.UnitPrice) OVER (partition by sd.ProductID),
	avg_value = AVG(sd.UnitPrice) OVER (partition by sd.ProductID)
from Sales.SalesOrderDetail sd
inner join Sales.SalesOrderHeader sh on sh.SalesOrderID = sd.SalesOrderID
ORDER BY sh.TerritoryID,sd.ProductID



--show avg,min and max values for each product in each territory along with 
--average,min and max values for the entire territory 
select DISTINCT 
	sh.TerritoryID,sd.ProductID,
	max_value_territory = MAX(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID),
	min_value_territory = MIN(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID),
	avg_value_territory = AVG(sd.UnitPrice) OVER (partition by sh.TerritoryID,sd.ProductID),
	max_value = MAX(sd.UnitPrice) OVER (partition by sd.ProductID),
	min_value = MIN(sd.UnitPrice) OVER (partition by sd.ProductID),
	avg_value = AVG(sd.UnitPrice) OVER (partition by sd.ProductID)
from Sales.SalesOrderDetail sd
inner join Sales.SalesOrderHeader sh on sh.SalesOrderID = sd.SalesOrderID
ORDER BY sh.TerritoryID,sd.ProductID

--




