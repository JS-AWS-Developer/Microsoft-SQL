Create a report showing sales person information with historical information on sales quota. 
Show me all the customers with more than one credit card. 
Show me all the customers with more than one "home" address
Show me all the customers without a shipping address. 
Display any active employee working for multiple department. 
Display all overseas shipping orders. 
