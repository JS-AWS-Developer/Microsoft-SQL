--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.  
--Aales order with same subtotal should get the same rank number. 

    
--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.  
--If there is two sales order with same subtotal, then use customerid to determine the rank.  


--Assign a rank to sales information from Sales.SalesOrderHeader based on subtotal.
--There should be a seperate rank for sales in each Territory


--Show me the 8th best sales in each territory 


--Show me the 8th worst sales in each territory 


--Show me the 8th worst sales in each territory  with territory information 


--Show me the best 5 sales in each territory with territory information for year 2001


--Show me the best 5 sales in each year for each territory with territory information. 


--show avg,min and max values for each product in each territory


--show avg,min and max values for each product for entire territory


--show avg,min and max values for each product in each territory along with 
--	average,min and max values for the entire territory 






