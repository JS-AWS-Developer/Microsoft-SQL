------------------------------------------------------
--use Sales.SalesPerson tabel for following questions. 
------------------------------------------------------

--1)Show all rows and all columns from Sales.SalesPerson table. 
--2)Show all rows and all columns from Sales.SalesPerson table. Order it by sales amount ytd ascending. 
--3)Show sales person's personid, sales quota,commision pct,sales and last year sales information for from Sales.SalesPerson table. 
--  Order it by sales amount decending.
--4)How many sales persons are there in the company  
--5)which sales person made highest sales so far in this year? 
--6)which sales person made least sales so far in this year? 
--7)show top 25 percent of sales person based on their previous year sales. 
--8)show the earning of each sales person so far in this year (use columns bonus and commission for computation).
--9)BONUS QUESTION: Order above result based on total earning so far. 
--10)Show all sales persons does not have a territory. 
--11)Show all sales persons with territory. 
--   which are the distinct territory IDs in the table. 
--12)show all sales persons working on TerritoryID 1. 
--13)BONUS QUESTION:  show the top sales persons working on TerritoryID 1 based on total sales made so far this year. 
--14)show all sales persons working on TerritoryID 6 with more than $3000000 sales so far this year. . 
--15)show sales person with no territory id and sales quota. 
--16)show sales persons with sales quota less than $280000 or sales greater than $4000000


---------------------------------------------------------
--use Sales.SalesTerritory table for following questions. 
---------------------------------------------------------
--17)show all the sales territories in USA. 
--18)show sales information of sales person working in USA using corelated sub query. 
--   use Sales.SalesTerritory and Sales.SalesPerson tables for this query 
--19)impliement above logic using an IN clause. 



---------------------------------------------------------
--use Production.Product table for following questions. 
---------------------------------------------------------
--20)select all produts with name starting with "chain" 			
--21)select all produts with name ends with "bolt" 			
--22)show name and color of all the produts. If the color column is null then display color as  "white" 
--   use ISNULL function for this

